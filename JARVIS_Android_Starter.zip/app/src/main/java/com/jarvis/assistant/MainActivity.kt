package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null
    private var onStatus: ((String) -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else onStatus?.invoke("Permiso de micrófono denegado")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            JarvisScreen(
                onListen = { result, status ->
                    onResult = result
                    onStatus = status
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        startListening()
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onSpeak = { speak(it) }
            )
        }
    }

    private fun startListening() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            onStatus?.invoke("El reconocimiento de voz no está disponible en este dispositivo")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con JARVIS")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("Te escucho…") }
            override fun onBeginningOfSpeech() { onStatus?.invoke("Escuchando…") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("Procesando…") }
            override fun onError(error: Int) { onStatus?.invoke("No pude reconocer la voz. Intenta otra vez.") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onResult?.invoke(text) else onStatus?.invoke("No escuché ninguna frase")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("es", "ES")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    onListen: ( (String) -> Unit, (String) -> Unit ) -> Unit,
    onSpeak: (String) -> Unit
) {
    var status by remember { mutableStateOf("SISTEMA EN ESPERA") }
    var lastHeard by remember { mutableStateOf("Estoy listo para ayudarte.") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF05080F)) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF071426), Color(0xFF03050A)))),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("J.A.R.V.I.S.", color = Color(0xFF8EDCFF), fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 7.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color(0xFF5BA9D6), fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(38.dp))
                    HologramCore()
                    Spacer(Modifier.height(34.dp))
                    Text(lastHeard, color = Color(0xFFD7EAF7), fontSize = 16.sp)
                    Spacer(Modifier.height(28.dp))
                    Button(
                        onClick = {
                            status = "INICIANDO RECONOCIMIENTO DE VOZ"
                            onListen(
                                { spoken ->
                                    lastHeard = "Tú: $spoken"
                                    val reply = respondTo(spoken)
                                    status = "JARVIS ACTIVO"
                                    lastHeard = "$spoken\n\nJARVIS: $reply"
                                    onSpeak(reply)
                                },
                                { newStatus -> status = newStatus }
                            )
                        },
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF123C5B)),
                        modifier = Modifier.height(54.dp).shadow(12.dp, RoundedCornerShape(28.dp))
                    ) {
                        Text("●  HABLAR CON JARVIS", color = Color(0xFFDDF5FF), letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("PROTOTIPO 0.1  •  MODO DE PRUEBA", color = Color(0xFF47718A), fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }
        }
    }
}

@Composable
private fun HologramCore() {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "pulseScale"
    )
    Canvas(modifier = Modifier.size(230.dp)) {
        val c = center
        val radius = size.minDimension * 0.34f * pulse
        drawCircle(Brush.radialGradient(listOf(Color(0x6655CFFF), Color(0x2255CFFF), Color.Transparent), c, radius * 1.7f), radius * 1.7f, c)
        drawCircle(Color(0xFF1C9BD1), radius, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f))
        drawCircle(Color(0x8866D8FF), radius * 0.78f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
        drawCircle(Color(0xFF8BE5FF), radius * 0.48f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
        drawCircle(Color(0xFF2B9FCB), radius * 0.16f, c)
        for (i in 0 until 36) {
            val angle = Math.toRadians((i * 10).toDouble())
            val inner = radius * 1.12f
            val outer = radius * if (i % 3 == 0) 1.28f else 1.20f
            val start = Offset(c.x + kotlin.math.cos(angle).toFloat() * inner, c.y + kotlin.math.sin(angle).toFloat() * inner)
            val end = Offset(c.x + kotlin.math.cos(angle).toFloat() * outer, c.y + kotlin.math.sin(angle).toFloat() * outer)
            drawLine(Color(0xFF55CFFF), start, end, strokeWidth = if (i % 3 == 0) 2f else 1f)
        }
    }
}

private fun respondTo(input: String): String {
    val s = input.lowercase(Locale.ROOT)
    return when {
        "hola" in s -> "Buenas. Estoy listo para ayudarte."
        "tu nombre" in s || "cómo te llamas" in s -> "Soy JARVIS, tu asistente personal."
        "hora" in s -> "Todavía no tengo conectado el servicio de hora."
        "abre" in s || "llama" in s || "envía" in s || "manda" in s ->
            "Esa función todavía no está conectada. Primero debemos configurar los permisos y las integraciones de Android."
        else -> "He recibido tu solicitud. Mi inteligencia avanzada se conectará en una próxima versión."
    }
}
