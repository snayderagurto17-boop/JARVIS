JARVIS Android Starter - prototipo 0.1

Qué incluye:
- Interfaz oscura con núcleo holográfico azul animado.
- Botón para reconocimiento de voz en español (requiere permiso de micrófono).
- Respuesta hablada con TextToSpeech de Android.
- Respuestas locales básicas de demostración.

Qué NO incluye todavía:
- Cerebro de IA conectado a un servicio avanzado.
- Palabra de activación permanente "JARVIS".
- Control universal de aplicaciones.
- Envío automático de mensajes o llamadas.
- Modo offline de IA generativa.

Compilación en la nube:
1. Crea un repositorio nuevo en GitHub desde el navegador.
2. Sube el contenido de esta carpeta al repositorio (mantén la estructura).
3. Abre la pestaña Actions y ejecuta "Build JARVIS APK" si no se inicia solo.
4. En la ejecución terminada, descarga el artefacto "JARVIS-debug-APK".
5. Descomprime el artefacto y abre app-debug.apk en Android para instalarlo.
   Android puede pedir permiso para instalar desde esa fuente.

Nota:
Este proyecto es un punto de partida. Las llamadas, mensajes, escucha de palabra
de activación, IA avanzada y controles del sistema requieren desarrollo adicional,
permisos, pruebas y, en algunos casos, servicios externos o APIs específicas.
